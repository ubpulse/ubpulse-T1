// Test_LXSMWD2.h : main header file for the TEST_LXSMWD2 application
//

#if !defined(AFX_TEST_LXSMWD2_H__5E5AA357_4746_4159_A92F_A00E53F3E7B2__INCLUDED_)
#define AFX_TEST_LXSMWD2_H__5E5AA357_4746_4159_A92F_A00E53F3E7B2__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CTest_LXSMWD2App:
// See Test_LXSMWD2.cpp for the implementation of this class
//

class CTest_LXSMWD2App : public CWinApp
{
public:
	CTest_LXSMWD2App();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTest_LXSMWD2App)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation
	//{{AFX_MSG(CTest_LXSMWD2App)
	afx_msg void OnAppAbout();
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TEST_LXSMWD2_H__5E5AA357_4746_4159_A92F_A00E53F3E7B2__INCLUDED_)
