//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Test_LXSMWD2.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_TEST_LTYPE                  129
#define IDD_DIALOG1                     130
#define IDD_DIALOG2                     131
#define IDD_DIALOG3                     132
#define IDD_DIALOG4                     133
#define IDC_EDIT_COUNT_RETURNDATA       1000
#define IDC_EDIT1                       1001
#define IDC_EDIT2                       1002
#define IDC_EDIT3                       1003
#define IDC_EDIT4                       1004
#define IDC_EDIT5                       1005
#define IDC_EDIT6                       1006
#define IDC_EDIT7                       1007
#define IDC_EDIT8                       1008
#define IDC_EDIT9                       1009
#define IDC_adcbit                      1010
#define IDC_BTN_MSGTGT                  1011
#define IDC_BUTTON1                     1012
#define IDC_BUTTON2                     1013
#define IDC_EDIT_MAXV_CH1               1014
#define IDC_EDIT_MAXV_CH2               1015
#define IDC_EDIT_MAXV_CH3               1016
#define IDC_EDIT_MAXV_CH4               1017
#define IDC_EDIT_MAXV_CH5               1018
#define IDC_offgenmthd1                 1019
#define IDC_offgenmthd2                 1020
#define IDC_offgenmthd3                 1021
#define IDC_offgenmthd4                 1022
#define IDC_offgenmthd5                 1023
#define IDC_offgenmthd6                 1024
#define IDC_offgenmthd7                 1025
#define IDC_offgenmthd8                 1026
#define IDC_offgenmthd9                 1027
#define IDC_ampgainch1                  1028
#define IDC_ampgainch2                  1029
#define IDC_ampgainch3                  1030
#define IDC_ampgainch4                  1031
#define IDC_ampgainch5                  1032
#define IDC_ampgainch6                  1033
#define IDC_ampgainch7                  1034
#define IDC_ampgainch8                  1035
#define IDC_ampgainch9                  1036
#define IDC_adc2bit                     1037
#define IDC_maxv                        1038
#define IDC_adcbitv                     1039
#define IDC_EDIT_MAXV_CH6               1040
#define IDC_EDIT_MAXV_CH7               1041
#define IDC_EDIT_MAXV_CH8               1042
#define IDC_EDIT_MAXV_CH9               1043
#define IDC_EDIT_MINV_CH1               1044
#define IDC_EDIT_MINV_CH2               1045
#define IDC_EDIT_MINV_CH3               1046
#define IDC_EDIT_MINV_CH4               1047
#define IDC_EDIT_MINV_CH5               1048
#define IDC_EDIT_MINV_CH6               1049
#define IDC_EDIT_MINV_CH7               1050
#define IDC_EDIT_MINV_CH8               1051
#define IDC_EDIT_MINV_CH9               1052
#define ID_MENU_OpenDev_NeuroStress     32772
#define ID_MENU_CloseDev                32773
#define ID_MENU_SetConfig_Msg           32775
#define ID_MENU_SetCount_ReturnData     32776
#define ID_MENU_Start_Stream            32777
#define ID_MENU_Stop_Stream             32778
#define ID_MENU_SetConfig_Channel       32779
#define ID_MENU_TestFunction            32780
#define ID_MENU_AnalogChannelInfo       32781
#define ID_MENU_PPGPulse                32782
#define ID_MENUITEM32783                32783
#define ID_MENU_SelectChannel           32784
#define ID_MENU_graphlag                32786
#define ID_MENU_graphsml                32787
#define ID_MENU_OpenDev_NeuroIQ         32788
#define ID_MENU_OpenDev_NeuroTUNING     32789
#define ID_MENU_OpenDev_NeuroTUNINGoption 32790
#define ID_MENU_ubpulseH1_OpenDevice    32791
#define ID_MENU_SoundOn                 32793
#define ID_MENU_SoundOff                32794
#define ID_MENU_ubpulseH3_OpenDevice    32795
#define ID_MENU_ubpulseT1_OpenDevice    32797
#define ID_MENU_RP920_OpenDevice        32798

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        134
#define _APS_NEXT_COMMAND_VALUE         32799
#define _APS_NEXT_CONTROL_VALUE         1054
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
