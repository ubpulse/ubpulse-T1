// Test_LXSMWD2View.h : interface of the CTest_LXSMWD2View class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_TEST_LXSMWD2VIEW_H__691CBD63_E850_4BC8_BE8B_E690578A8BE9__INCLUDED_)
#define AFX_TEST_LXSMWD2VIEW_H__691CBD63_E850_4BC8_BE8B_E690578A8BE9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#if (My64bit == 1) // 64��Ʈ�� ���̺귯�� import
#pragma comment(lib,"LIB_64bit\\LXSMWD2.lib")		// USB��ġ ��� ���̺귯�� ����Ʈ.
#pragma comment(lib,"LIB_64bit\\ACQPLOT.lib")		// íƮ ǥ���ϴ�  ���̺귯�� ����Ʈ. 
#elif (My32bit== 1)// 32��Ʈ�� ���̺귯�� import
#pragma comment(lib,"LIB_32bit\\LXSMWD2.lib")		// USB��ġ ��� ���̺귯�� ����Ʈ.
#pragma comment(lib,"LIB_32bit\\ACQPLOT.lib")		// íƮ ǥ���ϴ�  ���̺귯�� ����Ʈ. 
#endif


class CTest_LXSMWD2View : public CView
{
protected: // create from serialization only
	CTest_LXSMWD2View();
	DECLARE_DYNCREATE(CTest_LXSMWD2View)
	afx_msg LRESULT  OnStreamData(WPARAM wParam,LPARAM lParam);// �޽��� ó���ϴ� �Լ�.
	afx_msg LRESULT  OnPpgPulse(WPARAM wParam,LPARAM lParam);// �޽��� ó���ϴ� �Լ�.
	afx_msg LRESULT  OnDeviceDisconnect(WPARAM wParam,LPARAM lParam);	// ��ġ ���� ����.
// Attributes
public:
	CTest_LXSMWD2Doc* GetDocument();

// Operations
public:
	int DISPMAXCH, DISPDATANUM, DISPWIDTH;
	short Cnt_RetData;
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTest_LXSMWD2View)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation

public:
	float MaxV_CH[11];
	float MinV_CH[11];
	float Graph_Maximum;
	unsigned char Receive_ChSelect[11];
	virtual ~CTest_LXSMWD2View();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CTest_LXSMWD2View)
	afx_msg void OnMENUCloseDev();
	afx_msg void OnMENUSetConfigMsg();
	afx_msg void OnMENUSetCountReturnData();
	afx_msg void OnMENUStartStream();
	afx_msg void OnMENUStopStream();
	afx_msg void OnMENUPPGPulse();
	afx_msg void OnMENUgraphlag();
	afx_msg void OnMENUgraphsml();
	afx_msg void OnMENUubpulseH1OpenDevice();
	afx_msg void OnMENUSoundOn();
	afx_msg void OnMENUSoundOff();
	afx_msg void OnMENUubpulseH3OpenDevice();
	afx_msg void OnMENURP920OpenDevice();
	afx_msg void OnMENUubpulseT1OpenDevice();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in Test_LXSMWD2View.cpp
inline CTest_LXSMWD2Doc* CTest_LXSMWD2View::GetDocument()
   { return (CTest_LXSMWD2Doc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TEST_LXSMWD2VIEW_H__691CBD63_E850_4BC8_BE8B_E690578A8BE9__INCLUDED_)
