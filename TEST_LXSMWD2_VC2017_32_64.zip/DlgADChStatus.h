#if !defined(AFX_DLGADCHSTATUS_H__5B4F2CBF_1577_405E_B01B_826B9F0901D3__INCLUDED_)
#define AFX_DLGADCHSTATUS_H__5B4F2CBF_1577_405E_B01B_826B9F0901D3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgADChStatus.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDlgADChStatus dialog

class CDlgADChStatus : public CDialog
{
// Construction
public:
	CDlgADChStatus(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDlgADChStatus)
	enum { IDD = IDD_DIALOG2 };
	float	m_offsetch1;
	float	m_offsetch2;
	float	m_offsetch3;
	float	m_offsetch4;
	float	m_offsetch5;
	float	m_offsetch6;
	float	m_offsetch7;
	float	m_offsetch8;
	float	m_offsetch9;
	float	m_ampgain1;
	float	m_ampgain2;
	float	m_ampgain3;
	float	m_ampgain4;
	float	m_ampgain5;
	float	m_ampgain6;
	float	m_ampgain7;
	float	m_ampgain8;
	float	m_ampgain9;
	UINT	m_adcbit;
	UINT	m_adc2bit;
	float	m_adcbitv;
	float	m_maxv;
	BYTE	m_offgm1;
	BYTE	m_offgm2;
	BYTE	m_offgm3;
	BYTE	m_offgm4;
	BYTE	m_offgm5;
	BYTE	m_offgm6;
	BYTE	m_offgm7;
	BYTE	m_offgm8;
	BYTE	m_offgm9;
	float	m_minv_1;
	float	m_minv_2;
	float	m_minv_3;
	float	m_minv_4;
	float	m_minv_5;
	float	m_minv_6;
	float	m_minv_7;
	float	m_minv_8;
	float	m_minv_9;
	float	m_maxv_1;
	float	m_maxv_2;
	float	m_maxv_3;
	float	m_maxv_4;
	float	m_maxv_5;
	float	m_maxv_6;
	float	m_maxv_7;
	float	m_maxv_8;
	float	m_maxv_9;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgADChStatus)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDlgADChStatus)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGADCHSTATUS_H__5B4F2CBF_1577_405E_B01B_826B9F0901D3__INCLUDED_)
