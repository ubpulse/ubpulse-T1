// Test_LXSMWD2Doc.cpp : implementation of the CTest_LXSMWD2Doc class
//

#include "stdafx.h"
#include "Test_LXSMWD2.h"

#include "Test_LXSMWD2Doc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTest_LXSMWD2Doc

IMPLEMENT_DYNCREATE(CTest_LXSMWD2Doc, CDocument)

BEGIN_MESSAGE_MAP(CTest_LXSMWD2Doc, CDocument)
	//{{AFX_MSG_MAP(CTest_LXSMWD2Doc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTest_LXSMWD2Doc construction/destruction

CTest_LXSMWD2Doc::CTest_LXSMWD2Doc()
{
	// TODO: add one-time construction code here

}

CTest_LXSMWD2Doc::~CTest_LXSMWD2Doc()
{
}

BOOL CTest_LXSMWD2Doc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CTest_LXSMWD2Doc serialization

void CTest_LXSMWD2Doc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CTest_LXSMWD2Doc diagnostics

#ifdef _DEBUG
void CTest_LXSMWD2Doc::AssertValid() const
{
	CDocument::AssertValid();
}

void CTest_LXSMWD2Doc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CTest_LXSMWD2Doc commands
