#if !defined(AFX_DLGPPGPULSE_H__DA5C0146_BEFD_4F98_A75B_9C4648182107__INCLUDED_)
#define AFX_DLGPPGPULSE_H__DA5C0146_BEFD_4F98_A75B_9C4648182107__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgPpgPulse.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDlgPpgPulse dialog

class CDlgPpgPulse : public CDialog
{
// Construction
public:
	void Display_ConnDisordersts(char sts);
	void Display_SubjectSts(char sbjsts);
	CDlgPpgPulse(CWnd* pParent = NULL);   // standard constructor
	afx_msg LRESULT OnPpgPulse(WPARAM wParam,LPARAM lParam);	// �޽��� ó���ϴ� �Լ�.
	afx_msg LRESULT OnPpgLED(WPARAM wParam,LPARAM lParam);		// ������ ����, ������� �޽��� ó���ϴ� �Լ�.
	afx_msg LRESULT OnPpgSubject(WPARAM wParam,LPARAM lParam);	// ������ �ǰ�ü ��ġ���� �޽��� ó���ϴ� �Լ�.
// Dialog Data
	//{{AFX_DATA(CDlgPpgPulse)
	enum { IDD = IDD_DIALOG3 };
	float	m_BeatIntTime;
	int		m_BeatPerMinute;
	CString	m_PpgSubject;
	CString	m_PpgConnection;
	CString	m_PpgMalfunction;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgPpgPulse)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDlgPpgPulse)
	afx_msg void OnBtnMsgtgt();
	afx_msg void OnButton1();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGPPGPULSE_H__DA5C0146_BEFD_4F98_A75B_9C4648182107__INCLUDED_)
