// DlgCntRetData.cpp : implementation file
//

#include "stdafx.h"
#include "Test_LXSMWD2.h"
#include "DlgCntRetData.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgCntRetData dialog


CDlgCntRetData::CDlgCntRetData(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgCntRetData::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgCntRetData)
	m_Cnt_RetData = 0;
	//}}AFX_DATA_INIT
}


void CDlgCntRetData::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgCntRetData)
	DDX_Text(pDX, IDC_EDIT_COUNT_RETURNDATA, m_Cnt_RetData);
	DDV_MinMaxInt(pDX, m_Cnt_RetData, 1, 64);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgCntRetData, CDialog)
	//{{AFX_MSG_MAP(CDlgCntRetData)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgCntRetData message handlers
