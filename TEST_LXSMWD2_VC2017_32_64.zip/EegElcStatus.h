#if !defined(AFX_EEGELCSTATUS_H__D959B256_170F_45A8_A5AA_CBDDCD625B94__INCLUDED_)
#define AFX_EEGELCSTATUS_H__D959B256_170F_45A8_A5AA_CBDDCD625B94__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// EegElcStatus.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CEegElcStatus dialog

class CEegElcStatus : public CDialog
{
// Construction
public:
	void Display_Status(char contactsts);
	CEegElcStatus(CWnd* pParent = NULL);   // standard constructor
	afx_msg LRESULT OnEegElcSts(WPARAM wParam,LPARAM lParam);	// �������� ���� ���� �޽��� ó���ϴ� �Լ�.
// Dialog Data
	//{{AFX_DATA(CEegElcStatus)
	enum { IDD = IDD_DIALOG4 };
	CString	m_DescriptionSts;
	CString	m_Ch1Sts;
	CString	m_Ch2Sts;
	CString	m_RefSts;
	CString	m_GndSts;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CEegElcStatus)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CEegElcStatus)
	afx_msg void OnButton1();
	afx_msg void OnButton2();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_EEGELCSTATUS_H__D959B256_170F_45A8_A5AA_CBDDCD625B94__INCLUDED_)
