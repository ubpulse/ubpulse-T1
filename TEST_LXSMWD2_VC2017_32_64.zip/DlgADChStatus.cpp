// DlgADChStatus.cpp : implementation file
//

#include "stdafx.h"
#include "Test_LXSMWD2.h"
#include "DlgADChStatus.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgADChStatus dialog


CDlgADChStatus::CDlgADChStatus(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgADChStatus::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgADChStatus)
	m_offsetch1 = 0.0f;
	m_offsetch2 = 0.0f;
	m_offsetch3 = 0.0f;
	m_offsetch4 = 0.0f;
	m_offsetch5 = 0.0f;
	m_offsetch6 = 0.0f;
	m_offsetch7 = 0.0f;
	m_offsetch8 = 0.0f;
	m_offsetch9 = 0.0f;
	m_ampgain1 = 0.0f;
	m_ampgain2 = 0.0f;
	m_ampgain3 = 0.0f;
	m_ampgain4 = 0.0f;
	m_ampgain5 = 0.0f;
	m_ampgain6 = 0.0f;
	m_ampgain7 = 0.0f;
	m_ampgain8 = 0.0f;
	m_ampgain9 = 0.0f;
	m_adcbit = 0;
	m_adc2bit = 0;
	m_adcbitv = 0.0f;
	m_maxv = 0.0f;
	m_offgm1 = 0;
	m_offgm2 = 0;
	m_offgm3 = 0;
	m_offgm4 = 0;
	m_offgm5 = 0;
	m_offgm6 = 0;
	m_offgm7 = 0;
	m_offgm8 = 0;
	m_offgm9 = 0;
	m_minv_1 = 0.0f;
	m_minv_2 = 0.0f;
	m_minv_3 = 0.0f;
	m_minv_4 = 0.0f;
	m_minv_5 = 0.0f;
	m_minv_6 = 0.0f;
	m_minv_7 = 0.0f;
	m_minv_8 = 0.0f;
	m_minv_9 = 0.0f;
	m_maxv_1 = 0.0f;
	m_maxv_2 = 0.0f;
	m_maxv_3 = 0.0f;
	m_maxv_4 = 0.0f;
	m_maxv_5 = 0.0f;
	m_maxv_6 = 0.0f;
	m_maxv_7 = 0.0f;
	m_maxv_8 = 0.0f;
	m_maxv_9 = 0.0f;
	//}}AFX_DATA_INIT
}


void CDlgADChStatus::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgADChStatus)
	DDX_Text(pDX, IDC_EDIT1, m_offsetch1);
	DDX_Text(pDX, IDC_EDIT2, m_offsetch2);
	DDX_Text(pDX, IDC_EDIT3, m_offsetch3);
	DDX_Text(pDX, IDC_EDIT4, m_offsetch4);
	DDX_Text(pDX, IDC_EDIT5, m_offsetch5);
	DDX_Text(pDX, IDC_EDIT6, m_offsetch6);
	DDX_Text(pDX, IDC_EDIT7, m_offsetch7);
	DDX_Text(pDX, IDC_EDIT8, m_offsetch8);
	DDX_Text(pDX, IDC_EDIT9, m_offsetch9);
	DDX_Text(pDX, IDC_ampgainch1, m_ampgain1);
	DDX_Text(pDX, IDC_ampgainch2, m_ampgain2);
	DDX_Text(pDX, IDC_ampgainch3, m_ampgain3);
	DDX_Text(pDX, IDC_ampgainch4, m_ampgain4);
	DDX_Text(pDX, IDC_ampgainch5, m_ampgain5);
	DDX_Text(pDX, IDC_ampgainch6, m_ampgain6);
	DDX_Text(pDX, IDC_ampgainch7, m_ampgain7);
	DDX_Text(pDX, IDC_ampgainch8, m_ampgain8);
	DDX_Text(pDX, IDC_ampgainch9, m_ampgain9);
	DDX_Text(pDX, IDC_adcbit, m_adcbit);
	DDX_Text(pDX, IDC_adc2bit, m_adc2bit);
	DDX_Text(pDX, IDC_adcbitv, m_adcbitv);
	DDX_Text(pDX, IDC_maxv, m_maxv);
	DDX_Text(pDX, IDC_offgenmthd1, m_offgm1);
	DDX_Text(pDX, IDC_offgenmthd2, m_offgm2);
	DDX_Text(pDX, IDC_offgenmthd3, m_offgm3);
	DDX_Text(pDX, IDC_offgenmthd4, m_offgm4);
	DDX_Text(pDX, IDC_offgenmthd5, m_offgm5);
	DDX_Text(pDX, IDC_offgenmthd6, m_offgm6);
	DDX_Text(pDX, IDC_offgenmthd7, m_offgm7);
	DDX_Text(pDX, IDC_offgenmthd8, m_offgm8);
	DDX_Text(pDX, IDC_offgenmthd9, m_offgm9);
	DDX_Text(pDX, IDC_EDIT_MINV_CH1, m_minv_1);
	DDX_Text(pDX, IDC_EDIT_MINV_CH2, m_minv_2);
	DDX_Text(pDX, IDC_EDIT_MINV_CH3, m_minv_3);
	DDX_Text(pDX, IDC_EDIT_MINV_CH4, m_minv_4);
	DDX_Text(pDX, IDC_EDIT_MINV_CH5, m_minv_5);
	DDX_Text(pDX, IDC_EDIT_MINV_CH6, m_minv_6);
	DDX_Text(pDX, IDC_EDIT_MINV_CH7, m_minv_7);
	DDX_Text(pDX, IDC_EDIT_MINV_CH8, m_minv_8);
	DDX_Text(pDX, IDC_EDIT_MINV_CH9, m_minv_9);
	DDX_Text(pDX, IDC_EDIT_MAXV_CH1, m_maxv_1);
	DDX_Text(pDX, IDC_EDIT_MAXV_CH2, m_maxv_2);
	DDX_Text(pDX, IDC_EDIT_MAXV_CH3, m_maxv_3);
	DDX_Text(pDX, IDC_EDIT_MAXV_CH4, m_maxv_4);
	DDX_Text(pDX, IDC_EDIT_MAXV_CH5, m_maxv_5);
	DDX_Text(pDX, IDC_EDIT_MAXV_CH6, m_maxv_6);
	DDX_Text(pDX, IDC_EDIT_MAXV_CH7, m_maxv_7);
	DDX_Text(pDX, IDC_EDIT_MAXV_CH8, m_maxv_8);
	DDX_Text(pDX, IDC_EDIT_MAXV_CH9, m_maxv_9);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgADChStatus, CDialog)
	//{{AFX_MSG_MAP(CDlgADChStatus)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgADChStatus message handlers
